
package io.linfeng.common.validator.group;

/**
 * 阿里云
 *
 */
public interface AliyunGroup {
}
