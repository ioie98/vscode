林风社交论坛后台管理系统开源版基于Vue2+Element-UI开发，

node.js版本不要大于14。推荐版本号：node V10.16.3   npm V6.9.0

首次使用需要安装依赖

```
npm install
```



然后启动项目执行

```
npm run dev
```



打包项目执行



```
npm run build
```

