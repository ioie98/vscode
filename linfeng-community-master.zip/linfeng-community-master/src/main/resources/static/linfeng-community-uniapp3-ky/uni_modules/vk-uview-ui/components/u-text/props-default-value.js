export default {
	type: '',
	show: true,
	text: '',
	prefixIcon: '',
	suffixIcon: '',
	mode: '',
	href: '',
	format: '',
	call: false,
	openType: '',
	bold: false,
	block: false,
	lines: '',
	color: '#303133',
	size: 30,
	iconStyle: () => ({
		fontSize: '30rpx'
	}),
	decoration: 'none',
	margin: 0,
	lineHeight: '',
	align: 'left',
	wordWrap: 'normal',
	copyText: ""
}
